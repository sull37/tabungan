const API_URL = "https://tab.sultanmuhammadluthfi073.workers.dev/tabungan";
let tabunganData = JSON.parse(localStorage.getItem("tabunganData")) || [];

document.addEventListener("DOMContentLoaded", () => {
  renderTable();
  updateTotal();
  updateProgress();
  loadFromCloud();
  document.getElementById("tabungan-form").addEventListener("submit", addTabungan);
});

async function loadFromCloud() {
  try {
    const res = await fetch(API_URL);
    const data = await res.json();
    tabunganData = data;
    localStorage.setItem("tabunganData", JSON.stringify(tabunganData));
    renderTable();
    updateTotal();
    updateProgress();
  } catch (e) {
    console.log("Offline mode active");
  }
}

async function syncToCloud() {
  try {
    await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tabunganData),
    });
    console.log("✅ Data tersimpan di Cloudflare");
  } catch (e) {
    console.log("Gagal sync ke cloud");
  }
}

function addTabungan(e) {
  e.preventDefault();
  const nama = document.getElementById("nama").value;
  const jumlah = parseInt(document.getElementById("jumlah").value);
  const keterangan = document.getElementById("keterangan").value;
  const tanggal = new Date().toLocaleDateString("id-ID");

  tabunganData.push({ nama, jumlah, keterangan, tanggal });
  localStorage.setItem("tabunganData", JSON.stringify(tabunganData));
  renderTable();
  updateTotal();
  updateProgress();
  syncToCloud();
  e.target.reset();
}
