# 💚 Tabungan Romantis — Mas & Adek

> Aplikasi lucu & romantis buat mencatat tabungan berdua 💞  
> Bisa auto-sync ke Cloudflare Workers KV, dengan tampilan cute hijau-keemasan dan musik lembut 🎶  

---

## ✨ Fitur-Fitur
- ➕ Tambah / Edit / Hapus data tabungan  
- 💾 Simpan otomatis ke **localStorage + Cloudflare KV**  
- 📊 Grafik perbandingan Mas vs Adek  
- 💚 Progress bar target tabungan  
- 🌗 Mode gelap & animasi lembut  
- 🎶 Auto-play musik romantis (love-theme.mp3)  
- 💬 Pesan motivasi & chat mini antar user  

---

## 📂 Struktur Folder
```
tabungan-romantis-final/
│
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── main.js
│   ├── ui.js
│   ├── chart.js
│   ├── motivation.js
│   └── chat.js
└── assets/
    └── love-theme.mp3
```

---

## 💾 Cara Pasang

1️⃣ **Ekstrak ZIP**  
Unduh dan ekstrak `tabungan-romantis-final.zip`

2️⃣ **Tambahkan Musik**  
Letakkan file `love-theme.mp3` (musik romantis pilihanmu 🎶) di folder `assets/`

3️⃣ **Buka Aplikasi**  
Klik dua kali `index.html` → otomatis terbuka di browser  
> Aplikasi bisa langsung digunakan!

---

## ☁️ Sinkronisasi Cloudflare KV

Gunakan Worker milikmu:  
```
https://tab.sultanmuhammadluthfi073.workers.dev/
```

Worker ini otomatis:
- Menyimpan semua data tabungan global di key `mas-adek-tabungan`
- Mengirim data via POST setiap perubahan
- Mengambil data via GET saat pertama dibuka

---

## 🧠 Cek Data di Cloudflare

1. Masuk ke [Cloudflare Dashboard](https://dash.cloudflare.com)  
2. Buka menu **Workers → KV Storage → TABUNGAN_DB**  
3. Klik **View Data**  
4. Lihat key `mas-adek-tabungan` → berisi JSON data tabunganmu  

---

## ⚙️ Jalankan Lewat VSCode (opsional)

- Buka folder `tabungan-romantis-final`  
- Klik kanan `index.html` → pilih **Open with Live Server**  
- Aplikasi akan terbuka di `http://localhost:5500`  

---

## 💌 Catatan
> Kalau sedang offline, data tetap tersimpan di localStorage dan akan otomatis disinkronkan lagi saat koneksi kembali 🌐  

---

## 🧑‍💻 Dibuat Dengan Cinta 💚
Oleh: **Mas & Adek**  
Tema: *Hijau Keemasan Cute Romantis*  
Tech Stack: HTML + CSS + JS + Cloudflare KV  
